# password-generator
This generates a password that is above 6 characters long and will end if it is less than 6 characters
